/*
** Made By Yuanxiang Xie
** 这是测试整数的测试文件
*/

#include<stdio.h>
int main()
{
	int i = -1;
	int ii = +1;
	unsigned int j = 2u;
	unsigned int jj = 2U;
	long long k = -1l;
	long long kk = +1L;
	unsigned long long h = 1lu;

	printf("%d %d %u %u %lld %lld %llu\n", i, ii, j, jj, k, kk, h);
	return 0;
}

