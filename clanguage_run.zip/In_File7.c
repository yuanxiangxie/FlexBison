/*
** Made By Yuanxiang Xie
** 这是数字的特殊表示八进制和十六进制测试文件
*/

#include<stdio.h>
int main()
{
	int num = 0;
	int i = 00;
	int ii = 07;
	int j = 0x123;
	int jj = 0X123;
	unsigned long long k = 02U;
	long long kk = 02L;
	unsigned long long g = 0x123u;
	long long gg = 0X123L;
	printf("%d %d %d %d %d %llu %lld %llu %lld\n", num, i, ii, j, jj, k, kk, g, gg);
	return 0;
}

