#!/bin/bash

for str in `ls | grep .*_File[0-9]*$`
do
#echo $str
	rm -rf $str
done

for str in `ls | grep Out_.*`
do
	rm -rf $str
done

