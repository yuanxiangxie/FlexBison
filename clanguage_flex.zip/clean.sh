#!/bin/bash


for str in `ls | grep Out_.*.c`
do
#echo $str
	rm -rf $str
done

