/*
** Made By Yuanxiang Xie
** 这是用来测试分析注释的测试文件
*/

#include<stdio.h>
int main()
{
	printf("Hell World\n");
	return 0;
}

// 测试结束
