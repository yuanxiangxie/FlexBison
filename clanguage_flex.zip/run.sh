#!/bin/bash

inFile_Name=In_File
outFile_Name=Out_File


for str in `ls ${inFile_Name}*.c` 
do	
	programe_Name=${str%%.*}
	gcc -o $programe_Name $str
	
	if [ $? -eq 0 ]
	then
		rm -rf $programe_Name
	else
		echo "When Complier $str file, there are something wrong!"
	fi
done

for str in `ls ${inFile_Name}*.c`
do
	outFile="Out_"${str#*_}
	./clanguage $str $outFile
	echo "$str--->successful! The output file is $outFile!"
done



