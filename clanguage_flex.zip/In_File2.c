/*
** Made By Yuanxiang Xie
** 这是用来测试标识符的文件
*/

#include<stdio.h>
int main()
{
	int fores = 1;
	int _for = 2;
	int for2 = 3;
	printf("%d %d %d\n", fores, _for, for2);
	return 0;
}

