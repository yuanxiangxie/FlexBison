/*
** Made By Yuanxiang Xie
** 这是用来测试字符常量面值的文件
*/

#include<stdio.h>
int main()
{
	char ch = '\\';
	char ch1 = '\'';
	char ch2 = 'x';
	char ch3 = '\123';
	char ch4 = '\x1';
	char ch5 = '\n';
	printf("%c %c %c %c %c %c\n", ch, ch1, ch2, ch3, ch4, ch5);
	return 0;
}

