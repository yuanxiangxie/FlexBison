/*
** Made By Yuanxiang Xie
** 这是用来测试字符串的文件
*/

#include<stdio.h>
int main()
{
	char ch[100] = "This is My Email: yuanxiangboy@163.com, !@#$%^&*()_+?><:\\;~`'";
	printf("%s\n", ch);
	return 0;
}

