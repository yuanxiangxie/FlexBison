/*
** Made By Yuanxiang Xie
** 这是浮点数测试文件
*/ 

#include<stdio.h>
int main()
{
	double i = 2;
	double ii = 2.0;
	double j = 2.0F;
	double jj = 2.0f;
	double k = 2.3e-4;
	double kk =2.3e-4f;
	double h = .2;
	double hh = .2f;
	double g = .2e-4;
	double gg = .2e-4f;

	printf("%lf %lf %lf %lf %lf %lf %lf %lf %lf %lf\n", i, ii, j, jj, k, kk, h, hh, g, gg);
	return 0;
}

